<?php
namespace Okay\Helpers;

class RedisHelper {
    private $redis;
    private $cacheNamespace;

    public function __construct() {
        $this->redis = new \Redis();
        $this->redis->connect('127.0.0.1', 6379); // Подключение к Redis
        // Если нужен пароль:
        // $this->redis->auth('your_redis_password');

        // Namespace для изоляции сайтов
        $this->cacheNamespace = 'site_' . md5($_SERVER['HTTP_HOST']) . '_';
    }

    private function getKey(string $key): string {
        return $this->cacheNamespace . $key;
    }

    public function get(string $key) {
        $value = $this->redis->get($this->getKey($key));
        return $value ? unserialize($value) : false;
    }

    public function set(string $key, $value, int $ttl = 3600000): bool {
        $success = $this->redis->set($this->getKey($key), serialize($value));
        if ($ttl > 0) {
            $this->redis->expire($this->getKey($key), $ttl);
        }
        return $success;
    }

    public function delete(string $key): void {
        $this->redis->del($this->getKey($key));
    }

    public function flush(): void {
        // Очистка только текущего сайта по namespace
        $keys = $this->redis->keys($this->cacheNamespace . '*');
        foreach ($keys as $key) {
            $this->redis->del($key);
        }
    }
}