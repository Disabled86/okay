<?php

// Настройка логирования с самого начала
error_reporting(E_ALL); // Включаем отображение всех ошибок
ini_set('display_errors', 'Off'); // Отключаем вывод ошибок на экран
ini_set('log_errors', 'On'); // Включаем логирование ошибок
$logFile = __DIR__ . '/error.log'; // Файл для логов в той же папке

// Проверка доступности директории для записи логов
if (!is_writable(__DIR__)) {
    file_put_contents('php://stderr', "Папка " . __DIR__ . " недоступна для записи. Проверьте права.\n");
    die("Папка " . __DIR__ . " недоступна для записи. Проверьте права.");
}

ini_set('error_log', $logFile); // Указываем файл для логов

// Проверяем, доступен ли файл логов для записи
if (!file_exists($logFile)) {
    touch($logFile); // Создаем файл, если его нет
    if (!is_writable($logFile)) {
        file_put_contents('php://stderr', "Файл $logFile недоступен для записи. Проверьте права.\n");
        die("Файл $logFile недоступен для записи. Проверьте права.");
    }
}

// Логируем старт выполнения скрипта
error_log("Скрипт запускается: " . date('Y-m-d H:i:s'));

// Основной код
require_once __DIR__ . '/vendor/autoload.php'; // Путь к autoload.php

use Okay\Helpers\FilterHelper;
use Okay\Core\EntityFactory;
use Okay\Core\Settings;
use Okay\Core\Request;
use Okay\Core\Router;
use Okay\Core\Design;
use Okay\Core\FrontTranslations;

// Инициализация зависимостей
try {
    $entityFactory = new EntityFactory();
    $settings = new Settings();
    $request = new Request();
    $router = new Router();
    $design = new Design();
    $frontTranslations = new FrontTranslations();
    
    // Создание объекта FilterHelper
    $filterHelper = new FilterHelper(
        $entityFactory,
        $settings,
        $request,
        $router,
        $design,
        $frontTranslations
    );
} catch (Exception $e) {
    error_log("Ошибка инициализации зависимостей: " . $e->getMessage());
    die("Ошибка инициализации. Подробности в логах.");
}

// Пример данных
$testKey = 'test_key';
$testValue = ['example' => 'data'];

// Работа с Memcached
try {
    // Запись в кеш
    $filterHelper->setCache($testKey, $testValue);
    error_log("Данные записаны в кеш: ключ = $testKey, значение = " . json_encode($testValue));

    // Получение из кеша
    $fetchedValue = $filterHelper->getCache($testKey);
    error_log("Данные получены из кеша: " . json_encode($fetchedValue));

    if ($fetchedValue === $testValue) {
        echo "Данные успешно записаны и получены из кеша.";
        error_log("Успешно: данные совпадают.");
    } else {
        echo "Ошибка: данные не совпадают.";
        error_log("Ошибка: данные не совпадают.");
    }
} catch (Exception $e) {
    error_log("Ошибка работы с кешем: " . $e->getMessage());
    echo "Ошибка работы с кешем. Подробности в логах.";
}

// Логируем завершение выполнения скрипта
error_log("Скрипт завершён: " . date('Y-m-d H:i:s'));