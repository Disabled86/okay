<?php

namespace Okay\Helpers;

class MemcachedHelper {
    private $memcached;

    public function __construct() {
        $this->memcached = new \Memcached();
        $this->memcached->addServer('localhost', 11211);
    }

    public function get($key) {
        return $this->memcached->get($key);
    }

    public function set($key, $value, $ttl = 3000000) {
        $this->memcached->set($key, serialize($value), $ttl);
    }

    public function delete($key) {
        $this->memcached->delete($key);
    }

    public function flush() {
        $this->memcached->flush();
    }
}
?>