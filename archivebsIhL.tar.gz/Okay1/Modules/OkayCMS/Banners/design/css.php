<?php

use Okay\Core\TemplateConfig\Css;

return [
    (new Css('banners.css')),
];

