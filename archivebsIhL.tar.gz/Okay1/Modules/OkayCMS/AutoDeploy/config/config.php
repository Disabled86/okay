;<? exit(); ?>

; Путь к интерпретатору PHP со слешем в конце
; Пример path_to_php = '/usr/bin/'
path_to_php = ''