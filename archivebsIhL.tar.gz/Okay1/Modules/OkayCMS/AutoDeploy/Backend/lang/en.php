<?php

$lang['auto_deploy_title'] = 'Project auto deploy';
$lang['auto_deploy_disable_add'] = 'You can’t add or remove translations on the server, you can only edit';
