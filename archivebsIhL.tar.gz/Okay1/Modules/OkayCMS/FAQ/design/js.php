<?php

use Okay\Core\TemplateConfig\Js;

return [
    (new Js('faq.js')),
];
