<?php

$lang['left_faq_title'] = 'ხშირად დასმული კითხვები';
$lang['faq_title'] = 'ხშირად დასმული კითხვები';
$lang['faq_add'] = 'დაამატეთ ხშირად დასმული კითხვები';
$lang['no_faqs'] = 'ჩანაწერები არ არის';
$lang['faq_added'] = 'დასძინა კითხვები';
$lang['faq_updated'] = 'კითხვები განახლებულია';
$lang['faq_answer'] = 'პასუხი';
$lang['faq_question'] = 'კითხვა';