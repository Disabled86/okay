<?php

$lang['left_faq_title'] = 'FAQ';
$lang['faq_title'] = 'FAQ';
$lang['faq_add'] = 'Add FAQ';
$lang['no_faqs'] = 'No records';
$lang['faq_added'] = 'FAQ added';
$lang['faq_updated'] = 'FAQ updated';
$lang['faq_answer'] = 'Answer';
$lang['faq_question'] = 'Question';