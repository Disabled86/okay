<?php

$lang['left_faq_title'] = 'FAQ';
$lang['faq_title'] = 'FAQ';
$lang['faq_add'] = 'Добавить FAQ';
$lang['no_faqs'] = 'Нет записей';
$lang['faq_added'] = 'FAQ добавлен';
$lang['faq_updated'] = 'FAQ обновлен';
$lang['faq_answer'] = 'Ответ';
$lang['faq_question'] = 'Вопрос';