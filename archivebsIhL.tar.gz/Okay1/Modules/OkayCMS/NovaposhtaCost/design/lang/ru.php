<?php

$lang = array();
$lang['np_cart_city'] = "Город";
$lang['np_cart_street'] = "Улица";
$lang['np_cart_house'] = "Дом";
$lang['np_cart_apartment'] = "Квартира";
$lang['np_cart_warehouse'] = "Пункт выдачи";
$lang['np_cart_cod'] = "Наложенный платеж";
$lang['np_cart_term'] = "Время доставки (дней):";
$lang['np_need_select_city'] = "Выберите город, для расчета стоимости доставки";
$lang['np_select_city'] = "Выберите город";
$lang['np_cart_error_city'] = "Выберите город доставки";
$lang['np_cart_error_street'] = "Введите улицу доставки";
$lang['np_cart_error_house'] = "Введите номер дома доставки";
$lang['np_cart_select_warehouse'] = "Выберите отделение доставки";
$lang['np_cart_error_warehouse'] = "Выберите отделение доставки";
$lang['np_cart_calculate'] = "Вычисляем...";
$lang['np_form_enter_city'] = "Выберите город";
$lang['np_form_enter_street'] = "Введите улицу";
$lang['np_form_novaposhta_house'] = "Введите номер дома";
$lang['np_form_novaposhta_warehouses'] = "Выберите отделение";
$lang['np_order_city'] = "Город";
$lang['np_order_warehouse'] = "Пункт выдачи";
$lang['np_order_area'] = "Область";
$lang['np_order_street'] = "Улица";
$lang['np_order_house'] = "Дом";
$lang['np_order_apartment'] = "Квартира";
