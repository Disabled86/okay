<?php

$lang = array();
$lang['np_cart_city'] = "City";
$lang['np_cart_street'] = "Street";
$lang['np_cart_house'] = "Home";
$lang['np_cart_apartment'] = "Apartment";
$lang['np_cart_warehouse'] = "Point of issue";
$lang['np_cart_cod'] = "C.O.D";
$lang['np_cart_term'] = "Delivery time (days):";
$lang['np_need_select_city'] = "Select a city to calculate shipping costs";
$lang['np_select_city'] = "Select city";
$lang['np_cart_error_city'] = "Please select a delivery city";
$lang['np_cart_error_street'] = "Please enter delivery street";
$lang['np_cart_error_house'] = "Please enter the delivery house number";
$lang['np_cart_select_warehouse'] = "Please select a shipping office";
$lang['np_cart_error_warehouse'] = "Please select a shipping office";
$lang['np_cart_calculate'] = "Calculating...";
$lang['np_form_enter_city'] = 'Select a city';
$lang['np_form_enter_street'] = 'Enter Street';
$lang['np_form_novaposhta_house'] = 'Enter house number';
$lang['np_form_novaposhta_warehouses'] = 'Select Warehouse';
$lang['np_order_city'] = "City";
$lang['np_order_warehouse'] = "Warehouse";
$lang['np_order_area'] = "Area";
$lang['np_order_street'] = "Street";
$lang['np_order_house'] = "House";
$lang['np_order_apartment'] = "Apartment";
