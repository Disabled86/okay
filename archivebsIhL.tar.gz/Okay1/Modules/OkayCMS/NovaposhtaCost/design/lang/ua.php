<?php

$lang = array();
$lang['np_cart_city'] = "Місто";
$lang['np_cart_street'] = "Вулиця";
$lang['np_cart_house'] = "Дім";
$lang['np_cart_apartment'] = "Квартира";
$lang['np_cart_warehouse'] = "Пункт видачі";
$lang['np_cart_cod'] = "Післяплата";
$lang['np_cart_term'] = "Час доставки (днів):";
$lang['np_need_select_city'] = "Виберіть місто, для розрахунку вартості доставки";
$lang['np_select_city'] = "Виберіть місто";
$lang['np_cart_error_city'] = "Виберіть місто доставки";
$lang['np_cart_error_street'] = "Введіть вулицю доставки";
$lang['np_cart_error_house'] = "Введіть номер будинку доставки";
$lang['np_cart_select_warehouse'] = "Виберіть відділення доставки";
$lang['np_cart_error_warehouse'] = "Виберіть відділення доставки";
$lang['np_cart_calculate'] = "Обчислюємо...";
$lang['np_form_enter_city'] = "Виберіть місто";
$lang['np_form_enter_street'] = "Введіть вулицю";
$lang['np_form_novaposhta_house'] = "Введіть номер будинку";
$lang['np_form_novaposhta_warehouses'] = "Виберіть відділення";
$lang['np_order_city'] = "Місто";
$lang['np_order_warehouse'] = "Пункт видачі";
$lang['np_order_area'] = "Область";
$lang['np_order_street'] = "Вулиця";
$lang['np_order_house'] = "Будинок";
$lang['np_order_apartment'] = "Квартира";
