<?php
$lang['okay_cms__delivery_fields__module_title'] = "Поля для способів доставки";
$lang['okay_cms__delivery_fields__module_description_title'] = "Опис";
$lang['okay_cms__delivery_fields__module_description_content'] = "Модуль дозволяє додавати кастомні поля для способів доставки";
$lang['okay_cms__delivery_fields__module_instruction_title'] = "Інструкція";
$lang['okay_cms__delivery_fields__module_instruction_content'] = "Якщо активність поля була вимкнена, але для якогось замовлення воно було заповнено, таке поле відображатиметься для того замовлення.";
$lang['fd_field_required'] = "Обов'язкове";
$lang['fd_field_deliveries_list'] = "Способи доставки";
$lang['df_delete_delivery_field'] = "Видалити поле для всіх способів доставки";
$lang['df_order_on_map'] = "На мапі";
