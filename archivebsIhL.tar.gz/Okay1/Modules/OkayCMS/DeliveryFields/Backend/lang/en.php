<?php
$lang['okay_cms__delivery_fields__module_title'] = "Fields for delivery methods";
$lang['okay_cms__delivery_fields__module_description_title'] = "Description";
$lang['okay_cms__delivery_fields__module_description_content'] = "The module allows you to add custom fields for delivery methods";
$lang['okay_cms__delivery_fields__module_instruction_title'] = "Instruction";
$lang['okay_cms__delivery_fields__module_instruction_content'] = "If the activity of a field was disabled, but for some order it was filled, such a field will be displayed for that order.";
$lang['fd_field_required'] = "Required";
$lang['fd_field_deliveries_list'] = "Deliveries";
$lang['df_delete_delivery_field'] = "Delete field for all delivery methods";
$lang['df_order_on_map'] = "On the map";
