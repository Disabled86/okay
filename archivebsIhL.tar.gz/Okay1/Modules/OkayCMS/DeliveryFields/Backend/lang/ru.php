<?php
$lang['okay_cms__delivery_fields__module_title'] = "Поля для способов доставки";
$lang['okay_cms__delivery_fields__module_description_title'] = "Описание";
$lang['okay_cms__delivery_fields__module_description_content'] = "Модуль позволяет добавлять кастомные поля для способов доставки";
$lang['okay_cms__delivery_fields__module_instruction_title'] = "Инструкция";
$lang['okay_cms__delivery_fields__module_instruction_content'] = "Если активность поля была выключена, но для какого то заказа оно было заполнено, такое поле будет отображаться для того заказа.";
$lang['fd_field_required'] = "Обязательно";
$lang['fd_field_deliveries_list'] = "Способы доставки";
$lang['df_delete_delivery_field'] = "Удалить поле для всех способов доставки";
$lang['df_order_on_map'] = "На карте";
