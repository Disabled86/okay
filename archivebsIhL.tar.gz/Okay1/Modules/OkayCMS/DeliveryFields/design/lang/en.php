<?php

$lang['okaycms__delivery_fields_error'] = 'Fill the field "%s"';
