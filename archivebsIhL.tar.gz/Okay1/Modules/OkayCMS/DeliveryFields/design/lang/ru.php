<?php

$lang['okaycms__delivery_fields_error'] = 'Заполните поле "%s"';
