<?php


namespace Okay\Core\TemplateConfig;


class Css extends Common {}