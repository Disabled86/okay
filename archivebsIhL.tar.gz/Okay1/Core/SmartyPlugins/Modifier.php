<?php


namespace Okay\Core\SmartyPlugins;


class Modifier extends Plugin {}
