<?php

namespace Okay\Core;

use Memcached;

class MemcachedWrapper
{
    private $memcached;

    public function __construct()
    {
        $this->memcached = new Memcached();
        $this->memcached->addServer('127.0.0.1', 11211);
    }

    public function get(string $key)
    {
        return $this->memcached->get($key);
    }

    public function set(string $key, $value, int $ttl = 3600)
    {
        return $this->memcached->set($key, $value, $ttl);
    }

    public function delete(string $key)
    {
        return $this->memcached->delete($key);
    }

    public function flush()
    {
        return $this->memcached->flush();
    }
}