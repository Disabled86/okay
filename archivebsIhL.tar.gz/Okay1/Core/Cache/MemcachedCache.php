<?php

namespace Okay\Core\Cache;

use Memcached;

class MemcachedCache
{
    private $cache;

    public function __construct()
    {
        $this->cache = new Memcached();
        $this->cache->addServer('localhost', 11211); // Убедитесь, что адрес и порт правильные
    }

    public function get($key)
    {
        return $this->cache->get($key);
    }

    public function set($key, $value, $ttl = 3600000000)
    {
        return $this->cache->set($key, $value, $ttl);
    }

    public function delete($key)
    {
        return $this->cache->delete($key);
    }
}