<?php

namespace Okay\Core\OkayContainer\Reference;

/**
 * A value object representing a reference to a service.
 */
class ServiceReference extends AbstractReference {}
