<?php

namespace Okay\Core\OkayContainer\Reference;

/**
 * A value object representing a reference to a parameter.
 */
class ParameterReference extends AbstractReference {}
