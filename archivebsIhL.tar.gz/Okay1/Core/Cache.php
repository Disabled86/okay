<?php

namespace Okay\Core;

use Predis\Client;

class Cache
{
    private $client;

    public function __construct()
    {
        $this->client = new Client([
            'scheme' => 'tcp',
            'host'   => '127.0.0.1',
            'port'   => 6379,
        ]);
    }

    public function get($key)
    {
        return $this->client->get($key);
    }

    public function set($key, $value, $ttl)
    {
        $this->client->setex($key, $ttl, $value);
    }
}