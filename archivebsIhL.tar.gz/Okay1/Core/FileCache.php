<?php

namespace Okay\Core;

class FileCache
{
    private $cacheDir;

    public function __construct($cacheDir = 'cache/')
    {
        $this->cacheDir = rtrim($cacheDir, '/') . '/';
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0777, true);
        }
    }

    public function get($key)
    {
        $cacheFile = $this->cacheDir . md5($key) . '.cache';
        if (file_exists($cacheFile) && (filemtime($cacheFile) > (time() - 3600))) {
            return file_get_contents($cacheFile);
        }
        return false;
    }

    public function set($key, $value)
    {
        $cacheFile = $this->cacheDir . md5($key) . '.cache';
        file_put_contents($cacheFile, $value);
    }
}