<?php


namespace Okay\Core\TplMod\Nodes;


class SmartyIfNode extends BaseNode
{
    
    
}