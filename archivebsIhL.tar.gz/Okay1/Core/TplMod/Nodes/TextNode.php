<?php


namespace Okay\Core\TplMod\Nodes;


class TextNode extends BaseNode
{
    
}