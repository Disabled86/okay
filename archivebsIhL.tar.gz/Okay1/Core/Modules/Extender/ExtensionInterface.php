<?php


namespace Okay\Core\Modules\Extender;


interface ExtensionInterface {}