<?php
// Настройки базы данных для остатков
define('DB_HOST', 'localhost');
define('DB_NAME', 'waterglow_ru');
define('DB_USER', 'waterglow_ru');
define('DB_PASSWORD', '7wZyWVyxcyLDfTJV');

?>