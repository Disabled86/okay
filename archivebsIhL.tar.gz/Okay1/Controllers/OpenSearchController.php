<?php

namespace Okay\Controllers;

use Okay\Entities\ProductsEntity;
use Memcached;

class OpenSearchController extends AbstractController
{
    private $cache;

    public function __construct()
    {
        parent::__construct();
        $this->cache = new Memcached();
        $this->cache->addServer('localhost', 11211); // Убедитесь, что адрес и порт правильные
    }

    public function renderXml() {
        $this->design->setTemplatesDir('Okay/xml');
        $this->design->setCompiledDir('Okay/xml/compiled');

        if ($this->settings->get('site_favicon')) {
            $ext = pathinfo($this->settings->get('site_favicon'), PATHINFO_EXTENSION);
            $faviconMime = '';

            switch ($ext) {
                case 'png':
                    $faviconMime = 'image/png';
                    break;
                case 'jpeg':// no break
                case 'jpg':
                    $faviconMime = 'image/jpeg';
                    break;
                case 'ico':
                    $faviconMime = 'image/x-icon';
                    break;
            }
            $this->design->assign('favicon_mime', $faviconMime);
        }

        $this->response->setContent($this->design->fetch('opensearch.xml.tpl'), RESPONSE_XML);
    }

public function liveSearch(ProductsEntity $productsEntity)
{
    $query = $this->request->get('query', 'string');

    // Проверяем, есть ли результат в кэше
    $cacheKey = "live_search_" . md5($query);
    $cachedResult = $this->cache->get($cacheKey);

    if ($cachedResult) {
        $this->response->setContent($cachedResult, RESPONSE_JSON);
        return;
    }

    // Если результат не найден в кэше, выполняем поиск в базе данных
    $filter['keyword'] = $query;
    $filter['visible'] = true;
    $filter['limit'] = 10;

    $productsNames = $productsEntity->cols(['name'])->order('name')->find($filter);

    $res[] = $filter['keyword'];
    $res[] = $productsNames;

    $jsonResult = json_encode($res);

    // Сохраняем результат в кэш
    $this->cache->set($cacheKey, $jsonResult, 3000000000); // Кэшируем на 5 минут

    $this->response->setContent($jsonResult, RESPONSE_JSON);
}
}